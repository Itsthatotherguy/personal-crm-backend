export interface AuthResponse {
    accessToken: string;
    expiresIn: number;
}
