export interface JwtPayload {
    emailAddress: string;
}
